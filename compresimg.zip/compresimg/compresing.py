from os import path
from PIL import Image


def compress_img(filename):

    full_name = path.abspath(filename)
    base_name = path.basename(full_name)
    name = path.splitext(base_name)[0]
    cwd = path.dirname(full_name)
    new_filename = cwd + '\\' + 'compresed_' + name + '.jpg'
    img = Image.open(filename)
    if img.format != 'PNG':
        img.save(new_filename, "jpeg", quality=75)
    else:
        jpg_img = Image.new('RGB', img.size, (255,255,255))
        jpg_img.paste(img, (0, 0), img)
        jpg_img.save(new_filename, "jpeg", quality=75)
    return new_filename


if __name__ == "__main__":
    # testing function
    print(compress_img('test_img2.jpg'))